﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Descripción breve de asistenciaMostrar
/// </summary>
public class asistenciaMostrar
{
    public String? nombreRestaurante { get; set; }
    public DateTime fechaAsistencia { get; set; }
    public String? tipoAsistencia { get; set; }
}